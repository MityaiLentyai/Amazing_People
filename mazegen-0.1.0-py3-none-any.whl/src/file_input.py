import sys
from pydantic import BaseModel, Field, model_validator, field_validator, \
    ValidationError

class Config(BaseModel):
    width: int = Field(ge=1, alias="WIDTH")
    height: int = Field(ge=1, alias="HEIGHT")
    entry: tuple[int, int] = Field(alias="ENTRY")
    exit: tuple[int, int] = Field(alias="EXIT")
    output: str = Field(alias="OUTPUT_FILE")
    is_perfect: bool = Field(default=False, alias="PERFECT") # TODO: should it be mandatory present??? Cause if we have default value then pydantic doesn't error it out
    seed: int | None = Field(default=None, alias="SEED")

    @model_validator(mode="after")
    def entry_validator(self):

        x, y = self.entry

        if not (0 <= x < self.width):
            raise ValueError("Entry point X is outside the maze")

        if not (0 <= y < self.height):
            raise ValueError("Entry point Y is outside the maze")

        return self

    @model_validator(mode="after")
    def exit_validator(self):

        x, y = self.exit

        if not (0 <= x < self.width):
            raise ValueError("Exit point X is outside the maze")

        if not (0 <= y < self.height):
            raise ValueError("Exit point Y is outside the maze")

        return self

    @field_validator("entry", "exit", mode="before")
    @classmethod
    def parse_coordinates(cls, value):
        if isinstance(value, str):
            x, y = value.split(",")
            return int(x), int(y)
        return value


def parse_input(config_name: str) -> Config:
    config = {}
    try:
        with open(config_name, "r") as file:
            for line in file:
                parsed_line = line.split("#")[0].strip()
                if "=" in parsed_line:
                    key, value = parsed_line.split("=", 1)
                    # print(key,value) # TODO: delete when done testing
                    config.update({key: value})
        config = Config(**config)
        print(
            config)  # TODO: Delete this print when parser erroring is done
        return config
    # Now config is not a dict but a Pydantic Config object.
    # you can access it with print(config.field)
    except FileNotFoundError as e:
        print(f"File {config_name} not found, please make sure it exists and "
              f"try again.")
        exit()
    except PermissionError as e:
        print(f"Not enough access rights to either {config_name} or "
              f"{sys.argv[0]}\nPlease update the rights and try again\n"
              f"Exiting now xDD")
        exit()
    except ValidationError as e:
        print(e)
        exit()

if __name__ == "__main__":
    parse_input(sys.argv[1])

